I developed this application using Visual Studio 2019 on a Windows 11 machine. 

I was able to test the output successfully on a windows 10 machine by running the .exe file located in .\bin\Debug directory 
using windows Powershell, running the application directly will cause the terminal to close before output to be seen. 
